import {
    createBrowserRouter,
} from "react-router-dom";

import AppLayout from "./components/AppLayout";
import Dashboard from "./components/treasury/Dashboard";
import { Accounts } from "./components/treasury/Accounts";
import { ManageUsers } from "./components/treasury/ManageUsers";
import { Reports } from "./components/treasury/Reports";
import { Tasks } from "./components/treasury/Tasks";
import { Messages } from "./components/treasury/Messages";
import { Chat } from "./components/treasury/Chat";
import { Help } from "./components/treasury/Help";
  
const router = createBrowserRouter(
    [
        {
            element: <AppLayout/>,
            children: [
                {
                    path:"/",
                    element: (
                        <Dashboard />
                    )
                },
                {
                    path:"/users",
                    element: (
                        <ManageUsers />
                    )
                },
                {
                    path:"/reports",
                    element: (
                        <Reports />
                    )
                },
                {
                    path:"/accounts",
                    element: (
                        <Accounts />
                    )
                },
                {
                    path:"/tasks",
                    element: (
                        <Tasks />
                    )
                },
                {
                    path:"/messages",
                    element: (
                        <Messages />
                    )
                },
                {
                    path:"/help",
                    element: (
                        <Help />
                    )
                },
                {
                    path:"/chat",
                    element: (
                        <Chat />
                    )
                },
            ]
        },
    ]
);

export default router; 