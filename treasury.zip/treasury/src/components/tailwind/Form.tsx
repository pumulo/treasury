import React from "react";
import PencilIcon from '../../assets/images/pencil-icon.svg';
import { COLOR } from "./theme";

interface FormProps {
    title: string,
    register: any,
    handleSubmit: any,
    errors: any,
    onSubmit: any,
    children: string | JSX.Element | JSX.Element[]
}
export const TWForm = (props: FormProps) => {
    const { title, register, handleSubmit, errors, onSubmit, children } = props;

    return (
        <form
                className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4"
                onSubmit={handleSubmit(onSubmit)}
        >
            <div className="flex flex-row w-full border-b-2 mb-2">
                <div className="mb-2">
                    <span className="text-lg font-semibold tracking-wider mr-4">{title}</span>
                    <img className="float-right w-6 h-6" src={PencilIcon} alt="Edit" />
                </div>
            </div>
            
            {
                children
            }
        </form>
    )
}