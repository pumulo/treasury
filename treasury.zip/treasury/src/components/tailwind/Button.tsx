import React from "react";

interface ButtonProps {
    title: string;
    metadata: any;
    style?: string;
    type?: string | undefined;
}

export const TWButton = (props: ButtonProps) => {
    let { title, metadata, style, type } = props;
    if (!type) {
        type = 'button';
    }
    return (
        <button {...metadata} type={type} className={"bg-blue-900 text-lg text-slate-50 rounded-xl pl-3 pr-3 pt-1 m-1 pb-1 border-2 decoration-stone-100 focus:ring-2 shadow-lg transform active:scale-75 transition-transform " + style}>
            {title}
        </button>
    )
}