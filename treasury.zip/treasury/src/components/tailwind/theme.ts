export const COLOR = {
    primaryBG: 'bg-slate-50',
    secondaryBG: 'bg-slate-100',
    primaryText: 'text-black',
    secondaryText: 'text-slate-500',
    warningText: 'text-red-800',
    BUTTON: {
        primaryBG: 'bg-blue-800',
        primaryText: 'text-slate-50',
        secondaryBG: 'bg-slate-300',
        seconaryText: 'text-black',
        warningBG: 'bg-red-900',
        warningText: 'text-slate-50',
        positiveBG: 'bg-greeg-700',
        positiveText: 'text-slate-50',
        panelBG: 'bg-slate-100'
    }
}