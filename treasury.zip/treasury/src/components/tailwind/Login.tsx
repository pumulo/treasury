import React from "react";

export const TWLogin = () => {
    return (
        <div>
            <h1 className="text">Tailwind login</h1>
        </div>
    )
}