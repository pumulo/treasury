import React from "react";
import { TWPegaDiv } from "./PegaDiv";

const sampleWebEmbedTag = {
    id: 'theEmbed',
    action:'createCase',
    caseTypeID:'Firm-Treasury-Servicing-Work-RemoteDeposit',
    casePage:'assignmentWithStages',
    appAlias:'treasury-customer-service',
    pegaServerUrl:'https://sikap.pegatsdemo.com/prweb/',
    staticContentUrl:'https://prod-cdn.constellation.pega.io/8.23.0-110/react/prod/',
    authService:'pega',
    clientId:'20425172803433178214'
} 

export const TWScratchpad = () => {
    const displayPegaDiv = () => {
        return <TWPegaDiv {...sampleWebEmbedTag} ></TWPegaDiv>
    }
    return (
        <div className="bg-slate-200 p-4">

            {
                displayPegaDiv()
            }
        </div>
    )
}