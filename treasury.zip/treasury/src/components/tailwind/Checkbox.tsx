import React from "react";
import { RegisterOptions } from "react-hook-form";
import { COLOR } from "./theme";

interface CheckboxProps {
    id: string,
    name: string,
    label: string,
    register: any,
    rules?: RegisterOptions | undefined,
    errors: any,
    metadata?: any | undefined
}

export const TWCheckbox = (props: CheckboxProps) => {
  const {
    id,
    name,
    label,
    register,
    rules,
    errors,
    metadata
  } = props;
  return (
      <div className="flex flex-row py-3">
          <label className={"font-medium " + COLOR.primaryText} htmlFor={id}>
              {label}
            </label>
            <input
              type="checkbox"
              {...register(name, rules)}
              className={
                errors ?
                  `ml-2 w-6 h-6 shadow appearance-none border border-red-500 rounded py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline`:
                  `ml-2 w-6 h-6 border-solid border-gray-300 border py-2 px-4 rounded ring-2 ` + COLOR.secondaryText
                }
              autoFocus
              {...props}
            />
            {
              errors && <div className={'text-xs italic ' + COLOR.warningText}>{errors.message}</div>
            }
      </div>
  )
}