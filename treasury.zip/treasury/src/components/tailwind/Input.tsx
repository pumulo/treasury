import React from "react";
import { RegisterOptions, UseFormRegister } from "react-hook-form";
import { COLOR } from "./theme";

interface InputProps {
    id: string,
    type?: string | undefined,
    name: string,
    label: string,
    register: any,
    rules?: RegisterOptions | undefined,
    errors: any,
    metadata?: any | undefined
}

export const TWInput = (props: InputProps) => {
  const {
    id,
    name,
    label,
    register,
    rules,
    errors,
    metadata
  } = props;
  return (
      <div>
            
          <label className={"font-medium " + COLOR.primaryText} htmlFor={id}>
              {label}
            </label>
            <input
              {...register(name, rules)}
              className={
                errors ?
                  `shadow appearance-none border border-red-500 rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline`:
                  `border-solid border-gray-300 border py-2 px-4 w-full rounded ring-2 ` + COLOR.secondaryText
                }
              autoFocus
              {...props}
            />
            {
              errors && <div className={'text-xs italic ' + COLOR.warningText}>{errors.message}</div>
            }
      </div>
  )
}