import React from "react";
import {
    FaRegWindowMaximize,
} from 'react-icons/fa';
import { NavLink } from "react-router-dom";

interface SectionHeaderProps {
    title: string,
    maximizeRoute: string
}
export const SectionHeader = (props: SectionHeaderProps) => {
    return (
        <div className="flex text-2x1 items-baseline md:flex justify-between gap-2 min-w-full">
            <span className="font-bold text-2xl text-bofa ">
                {props.title}
            </span> 
            <NavLink
                to={props.maximizeRoute}
                id={props.title + 'id'}
            >
                <FaRegWindowMaximize className="flex justify-end cursor-pointer"></FaRegWindowMaximize>
            </NavLink>
            
        </div>
    )
}