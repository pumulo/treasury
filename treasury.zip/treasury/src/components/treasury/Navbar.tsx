import React, { useState } from "react";
import {
    Link,
    NavLink
} from 'react-router-dom';
import {
    FaBars,
    FaStar,
    FaQuestionCircle,
    FaComments,
    FaEnvelope,
    FaSignOutAlt
} from 'react-icons/fa';
import icon from '../../assets/images/bofa.jpeg';

const Navbar = () => {
    const links = [
        {name: 'Help', id: 'helpNavId', link: '/help', icon: <FaQuestionCircle></FaQuestionCircle>},
        {name: 'Chat', id: 'chatNavId', link: '/chat', icon: <FaComments></FaComments>},
        {name: 'Messages', id: 'messagesNavId', link: '/messages', icon: <FaEnvelope></FaEnvelope>},
        {name: 'Logout', id: 'logoutNavId', link: '/', icon: <FaSignOutAlt></FaSignOutAlt>},
    ]

    return (
        <div className="shadow-md w-full mb-auto top-0 left-0 bg-white">
            <div className="md:px-10 py-1 px-3 md:flex justify-between items-center">
                {/* logo and title here */}
                <Link to='/'>
                    <div className="flex text-2x1 cursor-pointer items-baseline gap-2">
                        <img src={icon} alt="Home" className='w-100 h-10'></img>
                        <span className="font-bold text-4xl text-bofa ">
                            CashPro
                        </span> 
                    </div>
                    <div className="flex flex-row text-2x1 cursor-pointer items-baseline gap-6">
                        
                        <NavLink
                            to='/'
                            id='homeNavLink'
                        >
                            <div className="flex justify-between cursor-pointer items-center gap-2"><FaBars></FaBars> Home</div>
                        </NavLink>
                        <NavLink
                            to='/favorites'
                            id='favoriteNavLink'
                        >
                        <div className="flex justify-between cursor-pointer items-center gap-2"><FaStar></FaStar> Favorites</div>
                            
                        </NavLink>
                    </div>
                </Link>

                {/* nav links here */}
                <div className="flex flex-col md:px-10 py-2 px-7 md:flex ">
                    <div className="text-base text-bofa-light">
                        Last Login: September 18, 2023 9:24 PM EST <br />
                        UserId: pumulosikaneta <br />
                    </div>
                    <div className="flex text-2xl cursor-pointer items-baseline gap-2 ">
                        <ul className='md:flex md-items-center text-bofa'>
                            {
                                links.map(
                                    link => (
                                        <li className='font-semibold my-7 md:my-0 md:mr-8 md:mt-2 cursor-pointer' key={link.id}>
                                            <NavLink
                                                to={link.link}
                                                id={link.id}
                                                title={link.name}
                                            >
                                                {link.icon}
                                            </NavLink>
                                        </li>
                                    )
                                )
                            }  
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    )
};

export default Navbar;