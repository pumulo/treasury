import React from "react";
import { Accounts } from "./Accounts";
import { ManageUsers } from "./ManageUsers";
import { Messages } from "./Messages";
import { Reports } from "./Reports";
import { Tasks } from "./Tasks";

const Dashboard = () => {
    return (
        <div className="min-h-screen h-screen min-w-full flex flex-col bg-bofa-light"> 
            <div className="ml-4 mt-2">Hello, Pumulo</div>
            <div className="flex flex-row min-w-full min-h-fit">
                {/* left panel */}
                <div className="flex flex-col w-1/2 min-h-fit ml-1 mr-1">
                    <ManageUsers />
                    <Reports />
                </div>
                {/* middle panel */}
                <div className="flex flex-col w-1/4 min-h-fit ml-1 mr-1">
                    <Accounts />
                </div>
                {/* rights panel */}
                <div className="flex flex-col w-1/4 min-h-fit ml-1 mr-1">
                    <Tasks />
                    <Messages />
                </div>
            </div>
        </div>
    )
}

export default Dashboard;