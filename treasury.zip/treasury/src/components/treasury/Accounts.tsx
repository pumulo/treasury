import React from "react";
import { TWPegaDiv } from "../tailwind/PegaDiv";
import { SectionHeader } from "./SectionHeader";

const remoteDepositPegaDiv = {
    id: 'theEmbed',
    action:'createCase',
    caseTypeID:'Firm-Treasury-Servicing-Work-RemoteDeposit',
    casePage:'assignmentWithStages',
    appAlias:'treasury-customer-service',
    pegaServerUrl:'https://sikap.pegatsdemo.com/prweb/',
    staticContentUrl:'https://prod-cdn.constellation.pega.io/8.23.0-110/react/prod/',
    authService:'pega',
    clientId:'20425172803433178214'
} 

export const Accounts = () => {
    return (
        <div className="flex flex-col bg-white bg-bofa-white m-4 min-w-fit p-2">
            <SectionHeader title='Remote Deposit' maximizeRoute="/accounts"></SectionHeader>
            
            <TWPegaDiv {...remoteDepositPegaDiv} ></TWPegaDiv>
        </div>
    )
}